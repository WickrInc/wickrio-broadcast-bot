import SendMessage from "./send"
import SentMessages from "./table"

export {
  SendMessage,
  SentMessages,
}