#!/bin/sh
pm2 restart processes.json --update-env
