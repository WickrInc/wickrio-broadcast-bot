'use strict'

export default Object.freeze({
  USER: 0,
  HASH: 1
});
