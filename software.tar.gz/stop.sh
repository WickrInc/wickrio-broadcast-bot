#!/bin/sh
npm stop
